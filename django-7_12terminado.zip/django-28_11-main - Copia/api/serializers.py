from rest_framework import serializers
from core.models import Conta, Cartao, Transactions, Emprestimos


class AccountSerializer(serializers.ModelSerializer):
    class Meta:
        model = Conta
        fields = ['id', 'agencia', 'numero']
        read_only_fields = ['numero']


class AccountDetailSerializer(AccountSerializer):
    class Meta(AccountSerializer.Meta):
        fields = AccountSerializer.Meta.fields + ['id', 'saldo', 'created_at']
        read_only_fields = AccountSerializer.Meta.read_only_fields + ['id', 'saldo', 'created_at']


class DepositoSerializer(serializers.Serializer):
    value = serializers.DecimalField(max_digits=5, decimal_places=2)
    
    class Meta:
        fields = ['value']

class SaqueSerializer(serializers.Serializer):
    value = serializers.DecimalField(max_digits=5, decimal_places=2)
    
    class Meta:
        fields = ['value']

class PixSerializer(serializers.ModelSerializer):
    value = serializers.DecimalField(max_digits=5, decimal_places=2)

    pagador = serializers.PrimaryKeyRelatedField(
        queryset=Conta.objects.all(),  # Add this line to specify the queryset
        many=False
    )

    recebedor = serializers.PrimaryKeyRelatedField(
        queryset=Conta.objects.all(),  # Add this line to specify the queryset
        many=False
    )

    class Meta:
        model = Transactions
        fields = ['pagador','recebedor','value']


class CartaoSerializer(serializers.ModelSerializer):
    class Meta:
        model = Cartao
        fields = ['account', 'number', 'cvv']

class EmprestimoSerializer(serializers.ModelSerializer):
    class Meta:
        model = Emprestimos
        fields = ['pedinte', 'value']



