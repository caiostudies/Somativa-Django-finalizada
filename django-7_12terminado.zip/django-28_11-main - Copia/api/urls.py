from django.urls import path, include
from rest_framework.routers import DefaultRouter
from api import views

router = DefaultRouter()
router.register('accounts', views.AccountViewSet)
router.register('card', views.CartaoViewset)
router.register('Pix', views.PixViewset)
router.register('emprestimo', views.EmprestimoViewset)

app_name = 'api'

urlpatterns = [
    path('', include(router.urls))
]
