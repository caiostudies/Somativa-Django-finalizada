from rest_framework import (
    viewsets,
    status,
    generics,
    mixins
)
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework_simplejwt import authentication as authenticationJWT
from core.models import Conta, Cartao, Transactions, Emprestimos
from api import serializers
import random, decimal

from rest_framework.decorators import action

from django.db.models import Q


class AccountViewSet(viewsets.ModelViewSet):
    # "SELECT * FROM contas";
    queryset = Conta.objects.all()
    authentication_classes = [authenticationJWT.JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        """Pegar contas para usuários autenticados"""
        queryset = self.queryset
        return queryset.filter(
            user=self.request.user
        ).order_by('-id').distinct()
    # "SELECT * FROM contas where user_id = 1";

    def get_serializer_class(self):
        if self.action == 'retrieve':
            return serializers.AccountDetailSerializer

        return serializers.AccountSerializer
    
    def create(self, request, *args, **kwargs):
        serializer = serializers.AccountDetailSerializer(data=request.data)
        if serializer.is_valid():
            agencia = '0001'
            numero = ''
            for n in range(8):
                numero += str(random.randint(0, 9))

            conta = Conta(
                user=self.request.user,
                numero=numero,
                agencia=agencia
            )

            conta.saldo = decimal.Decimal(0)

            conta.save()

            return Response({'message': 'Created'}, status=status.HTTP_201_CREATED)
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    @action(methods=['POST'], detail=True, url_path='sacar')
    def sacar(self, request, pk=None):
        conta = Conta.objects.filter(id=pk).first()
        
        serializer_recebido = serializers.SaqueSerializer(data=request.data)
        
        if serializer_recebido.is_valid() and conta:
            valor_saque = decimal.Decimal(serializer_recebido.validated_data.get('value'))
            saldo = decimal.Decimal(conta.saldo)
            
            comparacao = saldo.compare(valor_saque)
            
            if comparacao == 0 or comparacao == 1:
                novo_valor = 0 if saldo - valor_saque <= 0 else  saldo - valor_saque
                
                conta.saldo = novo_valor
                
                conta.save()
                
                return Response({"saldo": conta.saldo}, status=status.HTTP_200_OK)
            
            return Response({'message': 'Saldo insuficiente'}, status=status.HTTP_403_FORBIDDEN)
        
        return Response(serializer_recebido.errors, status=status.HTTP_400_BAD_REQUEST)
    
    
    @action(methods=['POST'], detail=True, url_path='depositar')
    def depositar(self, request, pk=None):
        conta = Conta.objects.filter(id=pk).first()
        serializer_recebido = serializers.DepositoSerializer(data=request.data)
        
        if serializer_recebido.is_valid() and conta:
            valor_deposito = decimal.Decimal(serializer_recebido.validated_data.get('value'))
            saldo = decimal.Decimal(conta.saldo)
            
            conta.saldo = saldo + valor_deposito
            conta.save()
            
            return Response({"saldo": conta.saldo}, status=status.HTTP_200_OK)
        
        return Response(serializer_recebido.errors, status=status.HTTP_400_BAD_REQUEST)
    
    


class CartaoViewset(viewsets.GenericViewSet, mixins.CreateModelMixin, mixins.ListModelMixin): 
    queryset = Cartao.objects.all()
    serializer_class = serializers.CartaoSerializer
    authentication_classes = [authenticationJWT.JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def create(self, request, pk=None):
        conta_logado = Conta.objects.filter(user = request.user).first()
        account = request.data.get("account")
        number = decimal.Decimal(request.data.get("number"))
        cvv = decimal.Decimal(request.data.get("cvv"))

        print(conta_logado)
        print(account)
        print(number)
        print(cvv)

        valor_minimo = 300
        valor_conta = conta_logado.saldo

        if valor_conta > valor_minimo:
            data = {
                "account": account, 
                "number": int(number), 
                "cvv": int(cvv)
            }

            print(data)

            serializer_cartao = serializers.CartaoSerializer(data=data)
            serializer_cartao.is_valid(raise_exception=True)
            serializer_cartao.save()

            
            return Response({'message': f'Seu cartão foi solicitado com sucesso'})
        return Response({'message': 'Seu cartão foi negado'}, status=status.HTTP_403_FORBIDDEN)
    


#novo
# class PixViewset(viewsets.GenericViewSet, mixins.CreateModelMixin, mixins.ListModelMixin): 
class PixViewset(viewsets.GenericViewSet): 
    queryset = Transactions.objects.all()
    serializer_class = serializers.PixSerializer
    authentication_classes = [authenticationJWT.JWTAuthentication]
    permission_classes = [IsAuthenticated]

    @action(methods=['POST'], detail=True, url_path='pix')
    def pix(self, request, pk=None):
        conta = Conta.objects.filter(id=pk).first()
        conta_logado = Conta.objects.filter(user = request.user).first()
        valor_pix = int(request.data.get("value"))       

        conta.saldo += valor_pix
        conta_logado.saldo -= valor_pix

        conta.save()
        conta_logado.save()

        transaction = {
            "value": valor_pix, 
            "pagador": conta_logado.id, 
            "recebedor": conta.id
        }

        serializer_transaction = serializers.PixSerializer(data=transaction)
        serializer_transaction.is_valid(raise_exception=True)
        serializer_transaction.save()


        return Response({"saldo": conta.saldo}, status=status.HTTP_200_OK)
    
    @action(methods=['GET'],detail=True, url_path='statement')
    def statement(self, request, pk=None):
        queryset = Transactions.objects.filter(
            Q(pagador=pk) | Q(recebedor=pk)
        ).order_by('-hora')
        serializer = self.get_serializer(queryset, many=True)

        return Response(serializer.data)
        
    


class EmprestimoViewset(viewsets.GenericViewSet, mixins.CreateModelMixin, mixins.ListModelMixin): 
    queryset = Emprestimos.objects.all()
    serializer_class = serializers.EmprestimoSerializer
    authentication_classes = [authenticationJWT.JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def create(self, request, pk=None):
        conta_logado = Conta.objects.filter(user = request.user).first()
        pedinte = request.data.get("pedinte")
        value = decimal.Decimal(request.data.get("value"))
    

        print(conta_logado)
       

        valor_minimo = value
        valor_conta = conta_logado.saldo

        if valor_conta > valor_minimo * 2:
            data = {
                "pedinte": pedinte, 
                "value": int(value)
            }

            print(data)

            serializer_emprestimo = serializers.EmprestimoSerializer(data=data)
            serializer_emprestimo.is_valid(raise_exception=True)
            serializer_emprestimo.save()

            
            return Response({'message': f'Seu empréstimo foi solicitado em breve estará na sua conta'})
        return Response({'message': 'Seu empréstimo foi recusado'}, status=status.HTTP_403_FORBIDDEN)
    



